<?php echo e($slot); ?>

<?php /**PATH /home/smartict/public_html/tech/bitfinexoptions.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>