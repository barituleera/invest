<?php $__env->startSection('auth_content'); ?>
<div class="outer-w3-agile col-xl">

    <div class="row">
        <div class="col-12">
            <div class="input- mg-b-pro-edt ">
                <h3 class="text-primary">Payment procedure</h3>
                <h6 class="text-dark">BTC: bc1q05p3xj0ja3gnrdyqs4hasgcksspht70ykmjkuw</h6>
                <h6 class="text-dark">ETH: 0x26Abb54a6793D1340E9B316cB83f0C0d0B60CE06</h6>
                <h6 class="text-dark">LTC: MSHAv9e1W45CoUaHEEwrMhZ37Adu7nPJU4</h6>
                <ul class="text-info mt-4">
                    <li><i class="fa fa-dot-circle-o"></i> All payment should be made into the above accounts</li>
                    <li><i class="fa fa-dot-circle-o"></i> After payment, kindly paste the transaction ID for confirmation</li>
                    <li><i class="fa fa-dot-circle-o"></i> After payment confirmation transfer the money from your wallet to your
                        investment</li>
                </ul>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-lg-2"></div>
                <div class="col-lg-8 mt-5">
                    <div class="form">
                        <form style="padding:3px;" role="form" method="post" action="<?php echo e(route('users.depositing')); ?>">
                            <?php echo csrf_field(); ?>
                            <input style="padding:5px;" class="form-control text-light" placeholder="Enter amount here" type="text" name="amount"><br />
                            <input style="padding:5px;" class="form-control text-light" placeholder="Enter blockchain transaction id here" type="text" name="trans_id"><br />
                            <select name="payMethod" class="form-control" id="">
                                <option disabled>Payment method</option>
                                <option value="bitcoin">Bitcoin</option>
                                <option value="Etherium">Etherium</option>
                                <option value="litcoin">Litcoin</option>
                            </select> <br>
                            <input type="submit" class="btn btn-primary" value="Continue">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\uer\Desktop\Pro\Lara\bitfinexoptions\resources\views/users/deposit.blade.php ENDPATH**/ ?>