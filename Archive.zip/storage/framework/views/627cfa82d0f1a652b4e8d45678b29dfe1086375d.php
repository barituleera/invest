<?php $__env->startSection('auth_content'); ?>
<div class="row">
    <div class="col-lg-12">
        
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <h3 class="text-success"><?php echo e(session()->get('success')); ?></h3>
                </div>
            <?php endif; ?>
        
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">
            <h3 class="text-danger"><?php echo e($error); ?></h3>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="outer-w3-agile col-12">
    <div class="bs-example widget-shadow table-responsive" data-example-id="hoverable-table">
        <table id="UserTable" class="UserTable table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Amount</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Date created</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $dpsn = 1;
                ?>

                <?php $__currentLoopData = $Alltrans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtrans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($dpsn++); ?></th>
                    <td>$<?php echo e(number_format($dtrans->amount)); ?></td>
                    <td><?php echo e($dtrans->type); ?></td>
                    <td><?php echo e($dtrans->status); ?></td>
                    <td><?php echo e($dtrans->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\uer\Desktop\Pro\Lara\bitfinexoptions\resources\views/users/transactions.blade.php ENDPATH**/ ?>