<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/jamesbarituleera/Desktop/projects/finex/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>