<?php $__env->startSection('auth_content'); ?>
<div class="outer-w3-agile col-xl">

    <div class="row">
        <div class="col-12">
            <div class="input- mg-b-pro-edt ">

                <h3 class="text-primary">Payment procedure</h3>

                <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h6 style="color:;" ><?php echo e($wallet->name); ?>: <?php echo e($wallet->wallet_address); ?></h6>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <ul class="text-info mt-4">
                    <li><i class="fa fa-dot-circle-o"></i> All payment should be made into any of above addresses</li>
                    <li><i class="fa fa-dot-circle-o"></i> After payment, kindly paste the transaction ID for confirmation</li>
                    <li><i class="fa fa-dot-circle-o"></i> After payment confirmation transfer the money from your wallet to your
                        investment</li>
                </ul>


        </div>

        <div class="container">
            <div class="row">
                <div class="col-lg-2"></div>
                <div class="col-lg-8 mt-5">
                    <div class="form">
                        <form style="padding:3px;" role="form" method="post" action="<?php echo e(route('users.depositing')); ?>">
                            <?php echo csrf_field(); ?>
                            <input style="padding:5px;" class="form-control text-light" placeholder="Enter amount here" type="text" name="amount"><br />
                            <input style="padding:5px;" class="form-control text-light" placeholder="Enter blockchain transaction id here" type="text" name="trans_id"><br />
                            <select name="payMethod" class="form-control" id="">
                                <option disabled>Payment method</option>
                                <option value="bitcoin">Bitcoin</option>
                                <option value="Etherium">Etherium</option>
                                <!--<option value="litcoin">Litcoin</option>-->
                            </select> <br>
                            <input type="submit" class="btn btn-primary" value="Continue">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamesbarituleera/Desktop/well-known/resources/views/users/deposit.blade.php ENDPATH**/ ?>