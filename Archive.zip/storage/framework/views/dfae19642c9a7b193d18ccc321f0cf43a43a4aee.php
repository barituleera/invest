<?php $__env->startSection('user-content'); ?>
<div class="content bg-dark">
    <div class="page-inner">
        <div class="mt-2 mb-4">
            <h1 class="title1 text-light">My Clients </h1>
        </div>
        <div class="row">
            <div class="col-lg-12">
                
                <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <h3 class="text-success"><?php echo e(session()->get('success')); ?></h3>
                </div>
                <?php endif; ?>
                

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger">
                    <h3 class="text-danger"><?php echo e($error); ?></h3>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="row py-3 mb-4">
            <div class="col">
                
            </div>
        </div>
        <div class="row mb-5">
            <div class="col text-center card p-4 bg-dark">
                <div class="bs-example widget-shadow table-responsive" data-example-id="hoverable-table">
                    <table class="UserTable table table-hover text-light">
                        <thead>
                            <tr>
                                <th>Actions</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>country</th>
                                <th>Reg created</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row">
                                    <button data-toggle="modal" data-target="#depositModal<?php echo e($user->id); ?>" class="btn btn-primary btn-sm">Payment</button>
                                    
                                    
                                </td>
                                <td>
                                    <?php echo e($user->first_name . " " . $user->last_name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->phone); ?></td>
                                <td><?php echo e($user->country); ?></td>
                                <td><?php echo e($user->created_at); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="depositModal<?php echo e($cuser->id); ?>" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header bg-dark">
                <div class="nothing-here">
                    <h4 class="modal-title text-warning"><?php echo e($cuser->first_name . ' '. $cuser->last_name); ?></h4><br>
                    
                </div>
                <button type="button" class="close text-light" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body bg-dark">
                <form style="padding:3px;" role="form" method="post" action="<?php echo e(route('admin.payment')); ?>">
                    <?php echo csrf_field(); ?>
                    <input style="padding:5px;" class="form-control text-light bg-dark" type="text" name="amount"><br />
                    <input class="form-control text-light bg-dark" value="<?php echo e($cuser->id); ?>" type="hidden" name="user_id">
                    <select name="trans_type" class="form-control text-light bg-dark" id="">
                        <option disabled>Payment type</option>
                        <option value="Profit">Profit</option>
                        <option value="Bonus">Bonus</option>
                        <option value="Referal Bonus">Referal Bonus</option>
                    </select> <br>
                    <input type="submit" class="btn btn-light" value="Continue">
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- /deposit Modal -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\uer\Desktop\Pro\Lara\bitfinexoptions\resources\views/admin/users.blade.php ENDPATH**/ ?>