<?php $__env->startSection('auth_content'); ?>
<div class="outer-w3-agile col-xl">


    <div class="container">
        <div class="">
            <div class="row">
                <div class="col-lg-3"></div>
            <div class="col-1g-6">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger mt-3">
                    <p class="text-danger"><?php echo e($error); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <h3 class="text-success"><?php echo e(session()->get('success')); ?></h3>
                </div>
                <?php endif; ?>

                <?php if(session()->has('failed')): ?>
                <div class="alert alert-danger">
                    <p class="text-danger"><?php echo e(session()->get('failed')); ?></p>
                </div>
                <?php endif; ?>

            </div>
            </div>

            <div class="row">
                <div class="col-lg-3"></div>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header bg-dark">
                        <h5 class="text-light">Withdrawal</h5>
                    </div>
                    <div class="card-body">
                        <div class="container">
                            <div class="form">
                                <form method="POST" action="<?php echo e(route('users.withdrawal_action')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="">amount</label>
                                        <input type="number" name="amount" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <select name="withdrawal_option" id="" class="form-control">
                                            <!--<option value="investment">Investment</option>-->
                                            <option value="profit">Profit</option>
                                            <option value="bonus">Bonus</option>
                                            <!--<option value="Profit">Referal bonus</option>-->
                                            
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-primary">Withdraw</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/smartict/public_html/tech/bitfinexoptions.com/resources/views/users/withdrawal.blade.php ENDPATH**/ ?>