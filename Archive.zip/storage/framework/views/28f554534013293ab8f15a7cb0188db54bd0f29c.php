<?php echo e($slot); ?>

<?php /**PATH /Users/jamesbarituleera/Desktop/well-known/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>