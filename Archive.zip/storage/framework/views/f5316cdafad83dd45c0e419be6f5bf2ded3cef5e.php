<?php $__env->startSection('user-content'); ?>
<div class="content bg-dark">
    <div class="page-inner">
        <div class="mt-2 mb-4">
            <h2 class="text-light pb-2">Welcome, <?php echo e(Auth::user()->first_name); ?>!</h2>

        </div>

        <!-- Beginning of  Dashboard Stats  -->
        <div class="row row-card-no-pd bg-dark shadow-lg">
            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="card card-stats card-round bg-dark">
                    <div class="card-body ">
                        <div class="row">
                            <div class="col-5">
                                <div class="icon-big text-center">
                                    <i class="fa fa-coins text-success"></i>
                                </div>
                            </div>
                            <div class="col-7 col-stats">
                                <div class="numbers">
                                    <p class="card-category">Balance</p>
                                    <h4 class="card-title text-light">$<?php echo e(number_format(Auth::user()->wallet->balance)); ?>.00</h4> <br>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="card card-stats card-round bg-dark">
                    <div class="card-body ">
                        <div class="row">
                            <div class="col-5">
                                <div class="icon-big text-center">
                                    <i class="fa fa-download text-warning"></i>
                                </div>
                            </div>
                            <div class="col-7 col-stats">
                                <div class="numbers">
                                    <p class="card-category">Investment</p>
                                    <h4 class="card-title text-light">$ <?php echo e(number_format(Auth::user()->wallet->investment)); ?>.00</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="card card-stats card-round bg-dark">
                    <div class="card-body ">
                        <div class="row">
                            <div class="col-5">
                                <div class="icon-big text-center">
                                    <i class="fa fa-coins text-success"></i>
                                </div>
                            </div>
                            <div class="col-7 col-stats">
                                <div class="numbers">
                                    <p class="card-category">Profit</p>
                                    <h4 class="card-title text-light">$<?php echo e(number_format(Auth::user()->wallet->profit)); ?>.00</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="card card-stats card-round bg-dark">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="icon-big text-center">
                                    <i class="fa fa-gift text-danger"></i>
                                </div>
                            </div>
                            <div class="col-7 col-stats">
                                <div class="numbers">
                                    <p class="card-category">Bonus</p>
                                    <h4 class="card-title text-light">$<?php echo e(number_format(Auth::user()->wallet->bonus)); ?>.00</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="card card-stats card-round bg-dark">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5">
                                <div class="icon-big text-center">
                                    <i class="fa fa-retweet text-primary"></i>
                                </div>
                            </div>
                            <div class="col-7 col-stats">
                                <div class="numbers">
                                    <p class="card-category">Ref. Bonus</p>
                                    <h4 class="card-title text-light">$<?php echo e(number_format(Auth::user()->wallet->ref_bonus)); ?>.00</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-2 mb-4">
            <h1 class="title1 text-light">Available packages</h1>
        </div>

        <div class="row mb-5">
            <div class="col-lg-4 p-4 card bg-dark shadow-lg">
                <div class="pricing-table purple border bg-dark shadow-lg">
                    <!-- Table Head -->
                    <div class="pricing-label d-inline">Fixed Price</div>
                    <h2 class="text-light">Starter</h2>
                    <!-- Price -->
                    <div class="price-tag">
                        <span class="symbol text-light">$</span>
                        <span class="amount text-light">500</span>
                    </div>
                    <!-- Features -->
                    <div class="pricing-features">
                        <div class="feature text-light">Minimum Possible Deposit:<span class="text-light">$500</span>
                        </div>
                        <div class="feature text-light">Maximum Possible Deposit:<span class="text-light">$999</span>
                        </div>
                        <div class="feature text-light">Minimum Return:<span class="text-light">$5000</span></div>
                        <div class="feature text-light">Maximum Return:<span class="text-light">$9000</span></div>
                        <div class="feature text-light">Gift Bonus:<span class="text-light">$50</span>
                        </div>
                        <div class="feature text-light">Duration:<span class="text-light">One
                                week</span></div>
                    </div> <br>
                    <!-- Button -->
                    <div class="">
                        <a class="btn btn-block btn-primary rounded rounded-pill" style=" border-radius: 40px;" href="<?php echo e(route('users.deposit')); ?>">Deposit</a>
                    </div>
                </div>
                <!-- Deposit for a plan Modal -->

                <!-- /deposit for a plan Modal -->
            </div>
            <div class="col-lg-4 p-4 card bg-dark shadow-lg">
                <div class="pricing-table purple border bg-dark shadow-lg">
                    <!-- Table Head -->
                    <div class="pricing-label d-inline">Fixed Price</div>
                    <h2 class="text-light">VIP</h2>
                    <!-- Price -->
                    <div class="price-tag">
                        <span class="symbol text-light">$</span>
                        <span class="amount text-light">3000</span>
                    </div>
                    <!-- Features -->
                    <div class="pricing-features">
                        <div class="feature text-light">Minimum Possible Deposit:<span class="text-light">$3000</span>
                        </div>
                        <div class="feature text-light">Maximum Possible Deposit:<span class="text-light">$5000</span>
                        </div>
                        <div class="feature text-light">Minimum Return:<span class="text-light">$30000</span></div>
                        <div class="feature text-light">Maximum Return:<span class="text-light">$50000</span></div>
                        <div class="feature text-light">Gift Bonus:<span class="text-light">$500</span>
                        </div>
                        <div class="feature text-light">Duration:<span class="text-light">One
                                month</span></div>
                    </div> <br>
                    <a class="btn btn-block btn-primary rounded rounded-pill" style=" border-radius: 40px;" href="<?php echo e(route('users.deposit')); ?>">Deposit</a>
                </div>
            </div>
        </div>

        <!-- Beginning of chart -->
        
    </div>
    <!-- end of chart -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamesbarituleera/Desktop/well-known/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>