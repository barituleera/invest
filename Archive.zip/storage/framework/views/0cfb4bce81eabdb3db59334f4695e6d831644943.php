<?php $__env->startComponent('mail::message'); ?>


<h2> Hello, <?php echo e($name); ?> </h2>

<?php
    $pattern = array('<br/>');
    $nb = explode('<br>', $body);
    foreach ($nb as $b) {
        echo $b.'<br>';
    }
?>

<?php $__env->startComponent('mail::button', ['url' => 'https:://www.keycoinify.com/dashboard']); ?>
visit your dashboard
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


For any questions, please contact us at <?php echo e(env('MAIL_FROM_ADDRESS')); ?> or whatsApp us on <?php echo e(env('APP_PHONE')); ?>

<br><br>

Thank you for investmenting with us,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/jamesbarituleera/Desktop/projects/finex/resources/views/mails/notification.blade.php ENDPATH**/ ?>